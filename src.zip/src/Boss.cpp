#include "Boss.h"

Boss::Boss()
{

}

Boss::~Boss()
{

}

void Boss::initialise(int x_origin, int y_origin, int health_x, int health_y, int health, int speed)
{
  _x = x_origin;
  _boss_y = y_origin;
  _health_bar_constant = 52;

  int direction = 0;

  if (direction == 0) {
    _velocity.x = speed;
  } else if (direction == 1) {
    _velocity.x = -speed;
  }

}

void Boss::draw(N5110 &lcd)
{
  boss_sprite(lcd);
  health_bar_draw(lcd);
}

void Boss::update()
{
  _x += _velocity.x;
  _y += _velocity.y;
}

void Boss::boss_sprite(N5110 &lcd)
{
  _boss_x = _x/8;
  lcd.drawRect(_boss_x + 4, _boss_y - 14, 2, 2, 0);   //1
  lcd.drawRect(_boss_x + 16, _boss_y - 14, 2, 2, 0);  //2
  lcd.drawRect(_boss_x + 6, _boss_y - 12, 2, 2, 0);   //3
  lcd.drawRect(_boss_x + 14, _boss_y - 12, 2, 2, 0);  //4
  lcd.drawRect(_boss_x + 4, _boss_y - 10, 14, 2, 0);  //5
  lcd.drawRect(_boss_x + 2, _boss_y - 8, 4, 2, 0);    //6
  lcd.drawRect(_boss_x + 8, _boss_y - 8, 6, 2, 0);    //7
  lcd.drawRect(_boss_x + 16, _boss_y - 8, 4, 2, 0);   //8
  lcd.drawRect(_boss_x + 2, _boss_y - 6, 18, 2, 0);   //9
  lcd.drawRect(_boss_x, _boss_y - 6, 2, 6, 0);        //10
  lcd.drawRect(_boss_x + 20, _boss_y - 6, 2, 6, 0);   //11
  lcd.drawRect(_boss_x + 4, _boss_y - 4, 14, 2, 0);   //12
  lcd.drawRect(_boss_x + 4, _boss_y - 2, 2, 2, 0);    //13
  lcd.drawRect(_boss_x + 16, _boss_y - 2, 2, 2, 0);   //14
  lcd.drawRect(_boss_x + 6, _boss_y, 4, 2, 0);        //15
  lcd.drawRect(_boss_x + 12, _boss_y, 4, 2, 0);       //16
}

void Boss::health_bar_draw(N5110 &lcd)
{
  lcd.drawRect(15, 8, 53, 5, 0); //health bar outline
  lcd.drawRect(16, 9, _health_bar_constant, 3, 1); //inner health bar
}

void Boss::decrement_health_constant()
{
  _health_bar_constant -= 2;
}

int Boss::get_health_bar_constant()
{
  return _health_bar_constant;
}

Vector2D Boss::get_velocity()
{
  Vector2D v = {_velocity.x,_velocity.y};
  return v;
}

Vector2D Boss::get_pos()
{
  Vector2D p = {_x,_y};
  return p;
}

void Boss::set_velocity(Vector2D v)
{
  _velocity.x = v.x;
  _velocity.y = v.y;
}

void Boss::set_pos(Vector2D p)
{
  _x = p.x;
  _y = p.y;
}

void Boss::add_boss_score()
{
  _boss_score += 100;
}

int Boss::get_boss_score()
{
  return _boss_score;
}

void Boss::add_boss_coins()
{
  _boss_coins += 1000;
}

int Boss::get_boss_coins()
{
  return _boss_coins;
}
