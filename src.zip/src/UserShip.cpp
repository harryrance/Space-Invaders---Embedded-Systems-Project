#include "UserShip.h"

UserShip::UserShip()
{

}

UserShip::~UserShip()
{

}

void UserShip::initialise(int y, int x_origin, int y_origin)
{
  _x_origin = x_origin;
  _y_origin = y_origin;
  _y = y;
  _speed = 1;

}

void UserShip::draw(N5110 &lcd)
{
  _x_origin = _x;
  lcd.setPixel(_x_origin,_y_origin);
  lcd.setPixel(_x_origin-1,_y_origin);
  lcd.setPixel(_x_origin-2,_y_origin);
  lcd.setPixel(_x_origin+1,_y_origin);
  lcd.setPixel(_x_origin+2,_y_origin);
  lcd.setPixel(_x_origin,_y_origin-1);
  lcd.setPixel(_x_origin-1,_y_origin-1);
  lcd.setPixel(_x_origin-2,_y_origin-1);
  lcd.setPixel(_x_origin+1,_y_origin-1);
  lcd.setPixel(_x_origin+2,_y_origin-1);
  lcd.setPixel(_x_origin,_y_origin-2);
  lcd.setPixel(_x_origin-1,_y_origin-2);
  lcd.setPixel(_x_origin+1,_y_origin-2);
  lcd.setPixel(_x_origin,_y_origin-3);
}

void UserShip::update(Direction d, float mag)
{
  _speed = int(mag*3.0f);

  if (d == E)
  {
    _x += _speed;
  } else if (d == W)
  {
    _x -=_speed/1.5;
  }

  if (_x < 3)
  {
    _x = 3;
  } else if (_x > 80)
  {
    _x = 80;
  }

}

Vector2D UserShip::get_pos()
{
  Vector2D p = {_x,_y};
  return p;
}

void UserShip::set_pos(Vector2D p)
{
  _x = p.x;
  _y = p.y;
}
