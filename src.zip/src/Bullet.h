#ifndef BULLET_H
#define BULLET_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"
#include "UserShip.h"

class Bullet
{

public:
  Bullet();
  ~Bullet();
  void initialise(int x_origin, int y_origin, int speed, int button_check);
  void draw(N5110 &lcd);
  void update();
  void check_button_press(Gamepad &pad);

  void set_velocity(Vector2D v);
  void set_position(Vector2D p);
  void add_score();
  void add_coins();
  Vector2D get_velocity();
  Vector2D get_position();
  int get_score();
  int get_coins();
  int _y;
  int _speed;
  int _button_check;

private:

  UserShip _get_ship;
  Vector2D _velocity;

  int _x_origin;
  int _y_origin;
  int _x;
  int _score;
  int _coins;

};

#endif
