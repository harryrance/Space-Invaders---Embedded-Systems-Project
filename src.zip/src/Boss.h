#ifndef BOSS_H
#define BOSS_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"

class Boss
{
public:
  Boss();
  ~Boss();
  void initialise(int x_origin, int y_origin, int health_x, int health_y, int health, int speed);
  void draw(N5110 &lcd);
  void boss_sprite(N5110 &lcd);
  void health_bar_draw(N5110 &lcd);
  void update();
  void set_velocity(Vector2D v);
  Vector2D get_velocity();
  Vector2D get_pos();
  void set_pos(Vector2D p);
  void decrement_health_constant();
  int get_health_bar_constant();
  void add_boss_score();
  void add_boss_coins();
  int get_boss_score();
  int get_boss_coins();

private:
  int _boss_x;
  int _boss_y;
  int _health_x;
  int _health_y;
  int _health;
  int _x;
  int _y;
  int _health_bar_constant;
  int _boss_score;
  int _boss_coins;

  Vector2D _velocity;
};
#endif
