////////// pre-processor directives //////////
#include "mbed.h"
#include "Gamepad.h"
#include "N5110.h"
#include "GameEngine.h"

#define US_X 42
#define AA_X 2
#define SPEED 1.5

////////// structs //////////
struct UserInput {
  Direction d;
  float mag;
};

////////// objects //////////
N5110 lcd(PTC9,PTC0,PTC7,PTD2,PTD1,PTC11);
Gamepad pad;
GameEngine engine;

////////// prototypes //////////
void init();
void render();
void update_game(UserInput input);

////////// functions //////////
int main()
{
  int fps = 30;

  init();
  render();
  wait(1.0f/fps);

  while(1){
    engine.read_input(pad);
    engine.update(pad);
    render();
    wait(1.0f/fps);
  }
}

void render()
{
  lcd.clear();
  engine.draw(lcd);
  lcd.refresh();
}

void init()
{
  lcd.init();
  pad.init();

  engine.initialise(US_X, AA_X, SPEED);

}
