#include "Bullet.h"

Bullet::Bullet()
{

}

Bullet::~Bullet()
{

}

void Bullet::initialise(int x_origin, int y_origin, int speed, int button_check)
{
  _x = x_origin;
  _y = y_origin;
  _button_check = button_check;
  _speed = speed;

}

void Bullet::check_button_press(Gamepad &pad)
{
  if (pad.check_event(Gamepad::A_PRESSED)){
    _button_check = 1;
    _speed = 2;
  }
}

void Bullet::draw(N5110 &lcd)
{
  _y_origin = _y;
  _x_origin = _x;

  if (_button_check){
    lcd.setPixel(_x_origin,_y_origin);
    lcd.setPixel(_x_origin,_y_origin-1);
  }
  if (_y < 10){
    _button_check = 0;
    _speed = 0;
    _y = 42;
  }
}

void Bullet::update()
{
  _x += _velocity.x;
  _y -= _velocity.y;

  int direction = 0;

  if(direction == 0)
  {
    _velocity.y = _speed;
  }
}

void Bullet::set_velocity(Vector2D v)
{
  _velocity.x = v.x;
  _velocity.y = v.y;
}

void Bullet::set_position(Vector2D p)
{
  _x = p.x;
  _y = p.y;
}

Vector2D Bullet::get_velocity()
{
  Vector2D v = {_velocity.x,_velocity.y};

  return v;
}

Vector2D Bullet::get_position()
{
  Vector2D p = {_x,_y};

  return p;
}

void Bullet::add_score()
{
  _score++;
}

int Bullet::get_score()
{
  return _score;
}

void Bullet::add_coins()
{
  _coins += 10;
}

int Bullet::get_coins()
{
  return _coins;
}
