#include "AliensArray.h"


AliensArray::AliensArray()
{

}

AliensArray::~AliensArray()
{

}

void AliensArray::initialise(int x_origin, int y_origin, int speed)
{
  _x = x_origin;
  _y = y_origin;

  int direction = 0;

  if (direction == 0) {
    _velocity.x = speed;
  } else if (direction == 1) {
    _velocity.x = -speed;
  }

}

void AliensArray::update()
{
  _x += _velocity.x;
  _y += _velocity.y;
}

void AliensArray::draw(N5110 &lcd)
{
  type_1_draw(lcd);
  type_1_1_draw(lcd);
  lcd.drawRect (0,0,84,48,0);

}

void AliensArray::type_1_draw(N5110 &lcd)
{
  int add_x = 0;
  _x_origin = _x/8;
  _y_origin = _y;
  for (int j = 0; j < 11; j++){
    add_x +=5;
    _array_x[0][j] = add_x;

  }

  for (int scan_j = 0; scan_j < 11; scan_j++){
    int ind = _array_x[0][scan_j];

    if (array_active[0][scan_j] == 1){
      lcd.setPixel((_x_origin+10+ind)-1,(_y_origin+10)-1);
      lcd.setPixel((_x_origin+10+ind),(_y_origin+10)-1);
      lcd.setPixel((_x_origin+10+ind),(_y_origin+10)+1);
      lcd.setPixel((_x_origin+10+ind)-1,(_y_origin+10)+1);
      lcd.setPixel((_x_origin+10+ind)+1,(_y_origin+10));
    }
  }

}

void AliensArray::type_1_1_draw(N5110 &lcd)
{
  int add_x = 0;
  _x_origin = _x/8;
  _y_origin = _y;
  for (int j = 0; j < 11; j++){
    add_x +=5;
    _array_x[1][j] = add_x;

  }

  for (int scan_j = 0; scan_j < 11; scan_j++){
    int ind = _array_x[1][scan_j];

    if (array_active[1][scan_j] == 1){
      lcd.setPixel((_x_origin+10+ind)-1,(_y_origin+16)-1);
      lcd.setPixel((_x_origin+10+ind),(_y_origin+16)-1);
      lcd.setPixel((_x_origin+10+ind),(_y_origin+16)+1);
      lcd.setPixel((_x_origin+10+ind)-1,(_y_origin+16)+1);
      lcd.setPixel((_x_origin+10+ind)+1,(_y_origin+16));
    }
  }

}

Vector2D AliensArray::get_velocity()
{
  Vector2D v = {_velocity.x,_velocity.y};
  return v;
}

Vector2D AliensArray::get_pos()
{
  Vector2D p = {_x,_y};
  return p;
}

void AliensArray::set_velocity(Vector2D v)
{
  _velocity.x = v.x;
  _velocity.y = v.y;
}

void AliensArray::set_pos(Vector2D p)
{
  _x = p.x;
  _y = p.y;
}
