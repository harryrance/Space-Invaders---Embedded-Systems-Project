#ifndef ALIENSARRAY_H
#define ALIENSARRAY_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"

class AliensArray
{
public:
  AliensArray();
  ~AliensArray();

  void initialise(int x_origin, int y_origin, int speed);
  void draw(N5110 &lcd);
  void type_1_draw(N5110 &lcd);
  void type_2_draw(N5110 &lcd);
  void type_1_1_draw(N5110 &lcd);
  void update();
  void set_velocity(Vector2D v);
  Vector2D get_velocity();
  Vector2D get_pos();
  void set_pos(Vector2D p);
  void remove_from_array(int i_remove, int j_remove);
  void is_active();
  int array_active[2][10];

private:
  int _x_origin;
  int _y_origin;
  int _x_origin_a;
  int _x;
  int _y;
  int _array_x[2][10];
  int _i_remove;
  int _j_remove;
  Vector2D _velocity;

};
#endif
