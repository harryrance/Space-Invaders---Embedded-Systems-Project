#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"
#include "Boss.h"
#include "UserShip.h"
#include "AliensArray.h"
#include "Bullet.h"

class GameEngine
{
public:
  GameEngine();
  ~GameEngine();
  void initialise(int ship_x_origin, int alien_x_origin, int speed);
  void read_input(Gamepad &pad);
  void update(Gamepad &pad);
  void draw(N5110 &lcd);

private:
  void check_alien_wall_collision(Gamepad &pad);
  void check_end_game(N5110 &lcd);
  void set_bullet_position(Gamepad &pad);
  void check_bullet_alien_collision(Gamepad &pad);
  void eliminate_alien_line_0();
  void eliminate_alien_line_1();
  void eliminate_alien_line_1_1();
  void reset_bullet();
  void reset_bullet_for_boss();
  void print_score_coins(N5110 &lcd);
  void move_boss(Gamepad &pad);
  void boss_fight_health_bar(N5110 &lcd);
  void check_fight_complete(N5110 &lcd);

  int _us_x_origin;
  int _aa_x_origin;
  int _x;
  int _xa;
  int _speed;
  int _set_bullet_x;
  int _boss_check;
  int _end_game_const;

  Boss _boss;
  Bullet _bullet;
  AliensArray _aliens;
  UserShip _ship;

  Direction _d;
  float _mag;
};

#endif
