#ifndef USERSHIP_H
#define USERSHIP_H

#include "mbed.h"
#include "N5110.h"
#include "Gamepad.h"

class UserShip
{
public:
  UserShip();
  ~UserShip();
  void initialise(int y, int x_origin, int y_origin);
  void draw(N5110 &lcd);
  void update(Direction d, float mag);
  Vector2D get_pos();
  void set_pos(Vector2D p);

private:
  int _x_origin;
  int _y_origin;
  int _x;
  int _y;
  int _speed;

};
#endif
