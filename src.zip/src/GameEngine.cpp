#include "GameEngine.h"

GameEngine::GameEngine()
{

}

GameEngine::~GameEngine()
{

}

void GameEngine::initialise(int ship_x_origin, int alien_x_origin, int speed)
{
  _us_x_origin = ship_x_origin;
  _aa_x_origin = alien_x_origin;
  _speed = speed;
  _boss_check = 0;
  _end_game_const = 0;

  _boss.initialise(31, 28, 0, 0, 0, 4);
  _bullet.initialise(0, 42, 0,0);
  _aliens.initialise(_aa_x_origin, 0, _speed);
  _ship.initialise(1, _us_x_origin, 47);

  for(int a = 0; a < 3; a++){
    for(int b = 0; b < 11; b++){
      _aliens.array_active[a][b] = 1;
    }
  }

}

void GameEngine::read_input(Gamepad &pad)
{
  _d = pad.get_direction();
  _mag = pad.get_mag();
  _bullet.check_button_press(pad);

}

void GameEngine::update(Gamepad &pad)
{
  _ship.update(_d,_mag);
  _aliens.update();
  _bullet.update();
  if (_boss_check){
    _boss.update();
  }
  move_boss(pad);
  set_bullet_position(pad);
  check_alien_wall_collision(pad);
  eliminate_alien_line_0();
  eliminate_alien_line_1_1();

}

void GameEngine::draw(N5110 &lcd)
{
  _ship.draw(lcd);
  _aliens.draw(lcd);
  _bullet.draw(lcd);
  if (_boss_check){
    _boss.draw(lcd);
    boss_fight_health_bar(lcd);
  }
  print_score_coins(lcd);
  check_end_game(lcd);
}

void GameEngine::eliminate_alien_line_0()
{
  Vector2D alien_pos_check = _aliens.get_pos();
  Vector2D bullet_pos = _bullet.get_position();

  if ((((alien_pos_check.x/8)+13) <= bullet_pos.x) && (((alien_pos_check.x/8)+16) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][0]){
        _aliens.array_active[0][0] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+18) <= bullet_pos.x) && (((alien_pos_check.x/8)+21) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][1]){
        _aliens.array_active[0][1] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+23) <= bullet_pos.x) && (((alien_pos_check.x/8)+26) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][2]){
        _aliens.array_active[0][2] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+28) <= bullet_pos.x) && (((alien_pos_check.x/8)+31) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][3]){
        _aliens.array_active[0][3] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+33) <= bullet_pos.x) && (((alien_pos_check.x/8)+36) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][4]){
        _aliens.array_active[0][4] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+38) <= bullet_pos.x) && (((alien_pos_check.x/8)+41) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][5]){
        _aliens.array_active[0][5] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+43) <= bullet_pos.x) && (((alien_pos_check.x/8)+46) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][6]){
        _aliens.array_active[0][6] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+48) <= bullet_pos.x) && (((alien_pos_check.x/8)+51) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][7]){
        _aliens.array_active[0][7] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+53) <= bullet_pos.x) && (((alien_pos_check.x/8)+56) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][8]){
        _aliens.array_active[0][8] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+58) <= bullet_pos.x) && (((alien_pos_check.x/8)+61) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][9]){
        _aliens.array_active[0][9] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+63) <= bullet_pos.x) && (((alien_pos_check.x/8)+66) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+10)) && _aliens.array_active[0][10]){
        _aliens.array_active[0][10] = 0;
        reset_bullet();
  }

}

void GameEngine::eliminate_alien_line_1_1()
{
  Vector2D alien_pos_check = _aliens.get_pos();
  Vector2D bullet_pos = _bullet.get_position();

  if ((((alien_pos_check.x/8)+13) <= bullet_pos.x) && (((alien_pos_check.x/8)+16) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][0]){
        _aliens.array_active[1][0] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+18) <= bullet_pos.x) && (((alien_pos_check.x/8)+21) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][1]){
        _aliens.array_active[1][1] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+23) <= bullet_pos.x) && (((alien_pos_check.x/8)+26) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][2]){
        _aliens.array_active[1][2] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+28) <= bullet_pos.x) && (((alien_pos_check.x/8)+31) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][3]){
        _aliens.array_active[1][3] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+33) <= bullet_pos.x) && (((alien_pos_check.x/8)+36) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][4]){
        _aliens.array_active[1][4] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+38) <= bullet_pos.x) && (((alien_pos_check.x/8)+41) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][5]){
        _aliens.array_active[1][5] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+43) <= bullet_pos.x) && (((alien_pos_check.x/8)+46) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][6]){
        _aliens.array_active[1][6] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+48) <= bullet_pos.x) && (((alien_pos_check.x/8)+51) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][7]){
        _aliens.array_active[1][7] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+53) <= bullet_pos.x) && (((alien_pos_check.x/8)+56) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][8]){
        _aliens.array_active[1][8] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+58) <= bullet_pos.x) && (((alien_pos_check.x/8)+61) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][9]){
        _aliens.array_active[1][9] = 0;
        reset_bullet();
  } else if ((((alien_pos_check.x/8)+63) <= bullet_pos.x) && (((alien_pos_check.x/8)+66) >= bullet_pos.x)
      && (bullet_pos.y <=(alien_pos_check.y+16)) && _aliens.array_active[1][10]){
        _aliens.array_active[1][10] = 0;
        reset_bullet();
  }

}

void GameEngine::reset_bullet()
{
  _bullet._button_check = 0;
  _bullet._speed = 0;
  _bullet._y = 42;
  _bullet.add_coins();
  _bullet.add_score();
}

void GameEngine::set_bullet_position(Gamepad &pad)
{
  Vector2D bullet_pos = _bullet.get_position();
  Vector2D ship_pos = _ship.get_pos();

  if (bullet_pos.y > 39) {
    bullet_pos.x = ship_pos.x;
    _set_bullet_x = ship_pos.x;
  } else if (bullet_pos.y <= 39){
    bullet_pos.x = _set_bullet_x;
  }

  _bullet.set_position(bullet_pos);
}

void GameEngine::check_alien_wall_collision(Gamepad &pad)
{
  Vector2D alien_pos = _aliens.get_pos();
  Vector2D alien_vel = _aliens.get_velocity();

  if (alien_pos.x > 122) {
    alien_pos.x = 122;
    alien_pos.y += 3;
    alien_vel.x = (-alien_vel.x) - 0.5;
  } else if (alien_pos.x <= -100) {
    alien_pos.x = -100;
    alien_pos.y += 3;
    alien_vel.x = (-alien_vel.x) + 0.5;
  }

  _aliens.set_pos(alien_pos);
  _aliens.set_velocity(alien_vel);
}

void GameEngine::move_boss(Gamepad &pad)
{
  Vector2D boss_pos = _boss.get_pos();
  Vector2D boss_vel = _boss.get_velocity();

  if (boss_pos.x > 360) {
    boss_pos.x = 360;
    boss_vel.x = -boss_vel.x;
  }else if (boss_pos.x < 130) {
    boss_pos.x = 130;
    boss_vel.x = -boss_vel.x;
  }
  _boss.set_pos(boss_pos);
  _boss.set_velocity(boss_vel);
}

void GameEngine::reset_bullet_for_boss()
{
  _bullet._button_check = 0;
  _bullet._speed = 0;
  _bullet._y = 42;
  _boss.add_boss_coins();
  _boss.add_boss_score();
}

void GameEngine::boss_fight_health_bar(N5110 &lcd)
{
  Vector2D bullet_pos = _bullet.get_position();
  Vector2D boss_pos = _boss.get_pos();
  int health_constant = _boss.get_health_bar_constant();

  if ((bullet_pos.x >= (boss_pos.x/8)) && (bullet_pos.x <= ((boss_pos.x/8) + 21)) && (bullet_pos.y <= boss_pos.y + 29)) {
    _boss.decrement_health_constant();
    reset_bullet();
  } if (health_constant < 0) {
    health_constant = 0;
    check_fight_complete(lcd);
    if (_end_game_const == 0){
      reset_bullet_for_boss();
    }
    _end_game_const = 1;
  }
}

void GameEngine::print_score_coins(N5110 &lcd)
{
  int user_score = _bullet.get_score();
  int user_coins = _bullet.get_coins();

  char buffer_score[14];
  sprintf(buffer_score,"%2d",user_score);
  char buffer_coins[14];
  sprintf(buffer_coins,"%2d",user_coins);
  lcd.printString(buffer_score, 4, 0);
  lcd.printString(buffer_coins, 62, 0);
}

void GameEngine::check_fight_complete(N5110 &lcd)
{
  int score = _bullet.get_score();
  int coins = _bullet.get_coins();
  int boss_score = _boss.get_boss_score();
  int boss_coins = _boss.get_boss_coins();

  int total_score = score + boss_score;
  int total_coins = coins + boss_coins;

  lcd.clear();

  char buffer_score[14];
  char buffer_coins[14];
  char buffer_complete[14];
  sprintf(buffer_score,"Score: %2d",total_score);
  sprintf(buffer_coins, "Coins: %2d",total_coins);
  sprintf(buffer_complete,"Game Complete!");

  lcd.printString(buffer_score,2,3);
  lcd.printString(buffer_coins,2,4);
  lcd.printString(buffer_complete,2,2);
}

void GameEngine::check_end_game(N5110 &lcd)
{
  Vector2D alien_pos = _aliens.get_pos();

  if (alien_pos.y >= 25) {
    for(int a = 0; a < 3; a++){
      for(int b = 0; b < 11; b++){
        _aliens.array_active[a][b] = 0;
      }
    }
    _boss_check = 1;
  } 
}
